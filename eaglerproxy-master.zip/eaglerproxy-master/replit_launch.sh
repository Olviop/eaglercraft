cd ~/$REPL_SLUG/build
node index.js
